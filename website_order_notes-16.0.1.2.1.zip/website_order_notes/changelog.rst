# Changelog
All notable changes to this project will be documented in this file.




## [Unreleased]


##[3.0.0] -11/october/2020
### Changed
--- Migrate the module in the version 14.